# VAE-for-Anomaly-Detection
MLP_VAE, Anomaly Detection, LSTM_VAE, Multivariate Time-Series Anomaly Detection，IndRNN_VAE, High_Frequency sensor Anomaly Detection,Tensorflow
